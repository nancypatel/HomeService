<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ApiContactController extends CI_Controller
{
    public function __construct()
    {
        //call CodeIgniter's default Constructor
        parent::__construct();
        //load database libray manually

        //load Model
        $this->load->model('ContactModel');
        $this->load->model('Users_model');
        $this->load->helper('url');
    }

    public function index()
    {
        $data['contact'] = $this->ContactModel->displayrecords();
        echo json_encode($data['contact']);
    }

    // public function add()
    // {
    //         $request= json_decode(file_get_contents('php://input'), TRUE);
    //         print_r($request)
    //         $data=$this->ContactModel->insert_form($request);

    // }


    
    
}
