<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<!DOCTYPE html>
<html>
	<head>
		<title>AboutUs</title>
    <link href="<?php echo base_url()?>Assets/Css/Header/about.css" rel="stylesheet">
		<link href="<?php echo base_url()?>Assets/Css/Home/carousel.css" rel="stylesheet">
	</head>
	<body>
    <div>
          <h1>
            <span>A</span>
            <span>b</span>
            <span>o</span>
            <span>u</span>
            <span>t</span>
            <span>U</span>
            <span>s</span>
          </h1>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br>
		<div class="box">
      		<div class="card">
        		<div class="imgBx">
            		<img src="" alt="images">
        		</div>
        		<div class="details">
            	<h2>My Intoduction<br><span>Design</span><span>Coding</span></h2>
        	</div>
      	</div>
    </div>
    <div>
      <p>Our Website provide you with and online service for home like plumbing,Application,Electrician,Etc...</p>
    </div>
	</body>
</html>